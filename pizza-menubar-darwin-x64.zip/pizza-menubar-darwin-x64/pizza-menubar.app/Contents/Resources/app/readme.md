# pizza-menubar

> File.pizza in your menubar

![](./screen.png)

## Usage
Download the app from here

## Dev
Built With Electron
```
$ npm install

# then use electron or electron-packager to build/run the app:
$ npm install electron-prebuilt -g
$ electron index.js
```

## License

MIT © [Nikhil Srivastava](http://niksrc.github.io)
